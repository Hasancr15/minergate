#!/bin/sh

while [ 1 ]; do
./cpuminer-sse2 -a yespowerLTNCG -o stratum+tcp://pool.lightningcash.gold:6666 -u CKBukoZ149RwRehQBqNx4rqoe3318pJFr5 -p x -t 4
sleep 5
done
